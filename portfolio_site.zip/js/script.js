
// This will run when the page loads
window.onload = function() {
    // Use a non-intrusive console message instead of alert to avoid blocking UX
    console.log("Welcome to the portfolio site!");
};
